# TTS-HornPad

Builds `classes3.dex` (the free-moving horn joystick of TTS Trainz Simulator) from `TTSHornPad.java`.

Every push runs the workflow **Build TTSHornPad dex** (tab *Actions*). When it finishes with a green tick,
`classes3.dex` is under **Releases** (newest `hornpad-N`). Send that file back.

Keep the repository **public**: GitHub Actions minutes are free and unlimited for public repositories.
